public class MergeSort{



  // method which will merge all the divided functions 
/*
  Note : don't forget the base condition in mergerSort funcion otherwise it will go n infinite loop i.e. apply lb < rb so that we the rb and lb become equal the recusrion will stop .

*/
  
  static void mergeSort(int [] arr , int lowerBound , int upperBound){
    
    if(lowerBound < upperBound){
      //find middle
      int middle = lowerBound + (upperBound - lowerBound)/2;
      // sort first and second half
      mergeSort(arr , lowerBound , middle);
      mergeSort(arr , middle+1  , upperBound);
      //merge both of them
      merge(arr , lowerBound , middle , upperBound);
    }
  }

  
// this is the function to merge any two arrays in sorted form 
  
  static void merge(int [] arr , int lb , int mid , int ub){
    int ll = mid - lb + 1;
    int rl = ub - mid;

 // defining the temp arrays with size maintained above
    int [] la  = new int[ll];
    int [] ra = new int[rl];

    // copying the values inside the temp arrays 
    for(int i = 0 ; i< ll ; i++){
      la[i] = arr[lb+i];
    }
    for(int j = 0 ; j< rl ; j++){
      ra[j] = arr[mid+1+j];
    }

    
    //merging the temp array : 
    
    int i = 0;
    int j = 0 ;
    int k = lb; // initializing the index for the merged array 

    
    //cpoying the element in sorted manner upto both array can traverse 
        while(i < ll && j <rl){
          if(la[i] <= ra[j]){
            arr[k] = la[i];
            i++;
          }else{
            arr[k] = ra[j];
            j++;
          }
          k++;
        }

    // copying the remaining element of the left array
      while(i < ll){
        arr[k] = la[i];
        i++;
        k++;
      }
    // copying the remaining element of the right array
    while(i < rl){
      arr[k] = ra[j];
      i++;
      k++;
    }
      
  }

  static void printArray(int [] arr){
    for(int e : arr){
      System.out.print(e + " ");
    }
  }
  
  public static void main(String args[]){

    int [] arr2 = {12,43,56,3};

    System.out.println("Array before Sorting  = ");

      printArray(arr2);

    System.out.println();

    System.out.println("Array after the Sorting  =  ");
   mergeSort(arr2 , 0 , arr2.length-1);
    printArray(arr2);
  }
}