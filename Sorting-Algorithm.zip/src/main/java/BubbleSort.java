import java.util.*;

public class BubbleSort{
public static Scanner sc = new Scanner(System.in);
  
public static void boobleSorting(int [] arr){
    int n = arr.length;

  for(int i=0 ; i<n; i++){
    for(int j = 0 ; j< n-i-1 ; j++){
      if(arr[j+1] < arr[j]){
        int temp = arr[j+1];
        arr[j+1] = arr[j];
        arr[j] = temp;
      }
    }
  }
  
  }
  
  public static void printArray(int [] arr){
    for(int e : arr){
      System.out.print(e + " ");
    }
  }

  public static void main(String args[]){
     System.out.print("enter the size of the Array  =  ");
    int n = sc.nextInt();
    int [] arr =  new int[n];

    for(int i=0; i<n ; i++){
      System.out.print("enter the value for arr["+i+"]  =  ");
      arr[i] = sc.nextInt();
    }

    System.out.println("Array before Sorting  = ");

      printArray(arr);

    System.out.println();

    System.out.println("Array after the Sorting  =  ");
    boobleSorting(arr);
    printArray(arr);

}
}