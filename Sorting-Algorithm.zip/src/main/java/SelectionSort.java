import java.util.*;

public class SelectionSort{
  public static Scanner sc = new Scanner(System.in);

  public static void selectionSorting(int [] arr){
    int n = arr.length;


    for(int i = 0 ; i<n-1 ; i++){
     // int min = arr[i];
      int min_idx = i;
      for(int j = i+1 ; j < n ; j++){
        if(arr[j] < arr[min_idx]) 
          min_idx = j;

          int temp = arr[min_idx];
          arr[min_idx] = arr[i];
          arr[i] = temp;
        
        
      }
    }
    
  }
  public static void printArray(int [] arr){
    for(int e : arr){
      System.out.print(e + " ");
    }
  }

  public static void main(String args[]){
    //  System.out.print("enter the size of the Array  =  ");
    // int n = sc.nextInt();
    // int [] arr =  new int[n];

    // for(int i=0; i<n ; i++){
    //   System.out.print("enter the value for arr["+i+"]  =  ");
    //   arr[i] = sc.nextInt();
    // }

    int [] arr2 = {12,43,56,3,10,5};

    System.out.println("Array before Sorting  = ");

      printArray(arr2);

    System.out.println();

    System.out.println("Array after the Sorting  =  ");
    selectionSorting(arr2);
    printArray(arr2);

}
}