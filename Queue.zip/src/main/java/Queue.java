public class Queue{
  static int size = 10;
  int [] arr = new int[size];
  int r;
  int f; 
                                   //  11,12,13,
  Queue(){
    this.r = -1;
    this.f = -1;
  }

  public boolean isEmpty(){
    return f == r;
  }
  public boolean isFull(){
    return r >= arr.length-1;
  }

  public void enqueue(int x){
    if(isFull()){
      System.out.println("Queue is full");
    }
   arr[r] = x;
     r++;
  }

  public void dequeue(){
    if(isEmpty()){
      System.out.println("Queue is empty");
    }

    for(int i = 0 ; i<r-1;i++){
      arr[i] = arr[i+1];
    }
      r--;
    
    }
  

 void print(){
  if(isEmpty()){
    System.out.println("Queue is empty ");
  }
   f = 0;
  for(int i = f ; i<=r ; i++){
    System.out.print(arr[i] + " ");
  }
}
  
  public static void main(String args[]){
    Queue queue = new Queue();
      queue.print();
      queue.enqueue(10);
      queue.enqueue(20);
      queue.enqueue(30);
      queue.enqueue(40);
      queue.print();
    System.out.println();
      queue.dequeue();
    queue.print();

  }
}