 public class StackUsingLinkedList{
       Node top;
   StackUsingLinkedList(){
     this.top = null;
   }
   
   static class Node{
     int data;
     Node next;

    
   }

   boolean isEmpty(){
     return top == null;
   }

   
   void push(int d){
     Node newNode = new Node();

     if(newNode == null){
       System.out.print("Heap OverFlow ");
       return;
     }

    newNode.data = d;
     newNode.next = top;
     top = newNode;
   }

   int peek(){
     if(!isEmpty()){
       return top.data;
     }else{
       System.out.println("Stack is empty");
       return -1;
     }
   }

   void pop(){
     if(top == null){
       System.out.print("Stack under flow");
       return;
     }
      System.out.print(top.data + " poped ");
     top = top.next;
   }

   void display(){
     if(isEmpty()){
       System.out.println("Stack is empty ");
     }else{
       Node current = top;

       while(current != null){
         System.out.print(current.data);
         current = current.next;
         if(current != null){
           System.out.print("-->");
         }
       }
     }
   }

   public static void main(String args[]){
     StackUsingLinkedList stack = new StackUsingLinkedList();

     stack.push(11);
      stack.push(12);
      stack.push(13);
      stack.push(14);

     stack.display();
      System.out.println();
     // while(stack.top != null){
     //   stack.pop();
     //   System.out.println(stack.top.data + " poped ");
     //   stack.top = stack.top.next;
     // }
     stack.pop();
     int x = stack.peek();
     System.out.println("peeked " + x);
   }
 }