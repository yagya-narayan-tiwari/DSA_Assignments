import java.util.Stack;

public class StringReversal{
  
  public static void main(String args[]){
    
    Stack<Character> stack = new Stack<>();
    // String name = "rahul";

    // for(int i = 0 ; i< name.length() ; i++){
    //   stack.push(name.charAt(i));
    // }
    
    // String reversed  = "";
    // while(!stack.isEmpty()){
    //   reversed += stack.pop();
    // }

    // System.out.println(reversed);
    // System.out.println(stack.size());

    String symbol = "{{[]}}(())";

   for(int i = 0 ; i<symbol.length() ; i++){
      if(symbol.charAt(i)=='{' || symbol.charAt(i)=='(' || symbol.charAt(i)=='['){
        stack.push(symbol.charAt(i));
      }else{
        if(stack.isEmpty()) {
        System.out.println("Not Balanced");
        return;
        } // Exit the program if unbalanced
        stack.pop();
      }
   }

    if(!stack.isEmpty()){
      System.out.print("Not Balanced ");
    }
    else{
      System.out.print(" Balanced ");
    }
  }

  
}