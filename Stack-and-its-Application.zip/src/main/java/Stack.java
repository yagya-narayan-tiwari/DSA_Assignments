import java.util.*;

public class Stack{
  public static Scanner sc = new Scanner(System.in);
  static int size = 10;
  int arr[] =  new int[size];
  int top;

  Stack(){
    this.top = -1;
    
  }

  boolean isEmpty(){
    return top < 0;
  }

  boolean isFull(){
    return top >=size-1;
  }

  void push(int data){
    if(isFull()){
      System.out.println("Stack is Full , can not add element ");
    }
    arr[++top] = data;
  }

  void pop(){
    if(isEmpty()){
      System.out.println("Stack in Empty, Nothing to delete ");
    }
    System.out.println(arr[top] + " deleted successfully ");
    top--;
  }

  int peek(){
    if(isEmpty()){
      System.out.println("Stack in Empty, Nothing to get ");
    }
    return arr[top];
  }

  void printStack(){
    int i = top;

    while(i>=0){
      System.out.print(arr[i] + "  ");
      i--;
    }
    System.out.println();
    
  }

  static int menuList(){
    System.out.println("0.EXIT ");
    System.out.println("1.PUSH ");
    System.out.println("2.PEEK ");
    System.out.println("3.POP ");
    System.out.println("4.DISPLAY STACK ");
    System.out.print("Enter Choice =  ");
    return sc.nextInt();

  }


  public static void main(String args[]){
    Stack stack = new Stack();
    int choice;
    while((choice = menuList()) != 0){
      switch(choice){
        case 1 : 
             System.out.println("Push Operation :-  ");
            System.out.print("Enter the data to push =  ");
            stack.push(sc.nextInt());
          break;
        case 2 : 
          System.out.println("Peek Operation :-  ");
          System.out.println("peeked element = " + stack.peek());
          break;
        case 3 : 
          System.out.println("Pop Operation :-   ");
          stack.pop();
          break;
        case 4 : 
          System.out.println("Stack Printling Operation :-   ");
          stack.printStack();
          break;
      }
    }
  }
}